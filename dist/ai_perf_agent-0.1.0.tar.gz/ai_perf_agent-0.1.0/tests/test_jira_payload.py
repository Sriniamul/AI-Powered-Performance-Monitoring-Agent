from agent.jira.jira_payload_builder import build_issue_payload


def test_payload_contains_project_and_summary(monkeypatch):
    monkeypatch.setenv("JIRA_PROJECT_KEY", "PERF")
    payload = build_issue_payload(
        {"jira": {"project_key_env": "JIRA_PROJECT_KEY", "default_issue_type": "Bug"}},
        {"service_name": "svc", "environment": "demo", "timestamp": "now", "cpu_percent": 90, "memory_percent": 10},
        {"severity": "high", "reason": "cpu", "capture_heap_dump": False, "capture_thread_dump": True},
        {"summary": "High CPU", "recommendation": "Check thread dump"},
    )
    assert payload["fields"]["project"]["key"] == "PERF"
    assert "AI Alert" in payload["fields"]["summary"]
